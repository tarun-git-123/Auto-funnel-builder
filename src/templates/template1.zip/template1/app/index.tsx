import Home from './home';
import Layout from './layout';

export default function Template1LandingPreview() {
  return (
      <Layout>
        <Home/>
      </Layout>
  );
}
