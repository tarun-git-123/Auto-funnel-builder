import PricingSection from "../../components/PricingSection";
import CtaSection from "../../components/CtaSection";

export default function Pricing() {
  return (
    <>
      <PricingSection />
      <CtaSection />
    </>
  );
} 