export default function ThankYou() {
  return (
    <main className="p-10 text-center">
      <h2 className="text-3xl font-semibold">Thank You!</h2>
      <p className="mt-4">Your order has been successfully placed.</p>
    </main>
  );
}