
    export default function Home() {
      return (
        <div style={{ backgroundColor: "#222222", color: "#dddddd" }}>
          <h1>CompliancePlus</h1>
          <p>Compliance Plus Inc</p>
          <p>789 Oak Blvd, Chicago, IL 60601 | EIN: 56-7890123</p>
          hero5
          services1
          how2
          pricing2
          cta4
        </div>
      )
    }
  