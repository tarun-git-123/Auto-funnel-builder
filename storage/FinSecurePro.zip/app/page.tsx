
    export default function Home() {
      return (
        <div style={{ backgroundColor: "#0044cc", color: "#00cc88" }}>
          <h1>FinSecurePro</h1>
          <p>FinSecure LLC</p>
          <p>123 Main Street, New York, NY 10001 | EIN: 12-3456789</p>
          hero3
          services1
          how5
          pricing4
          cta2
        </div>
      )
    }
  