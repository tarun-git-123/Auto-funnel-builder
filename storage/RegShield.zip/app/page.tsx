
    export default function Home() {
      return (
        <div style={{ backgroundColor: "#5500aa", color: "#00aa55" }}>
          <h1>RegShield</h1>
          <p>Regulatory Shield LLC</p>
          <p>654 Cedar Road, Dallas, TX 75001 | EIN: 33-4455667</p>
          hero4
          services3
          how3
          pricing2
          cta2
        </div>
      )
    }
  