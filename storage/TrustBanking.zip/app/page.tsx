
    export default function Home() {
      return (
        <div style={{ backgroundColor: "#cc0000", color: "#ffaa00" }}>
          <h1>TrustBanking</h1>
          <p>Trust Banking Corp</p>
          <p>456 Elm Avenue, Los Angeles, CA 90001 | EIN: 98-7654321</p>
          hero2
          services2
          how1
          pricing4
          cta4
        </div>
      )
    }
  