
    export default function Home() {
      return (
        <div style={{ backgroundColor: "#0088cc", color: "#ff6600" }}>
          <h1>SecureFunds</h1>
          <p>Secure Funds Ltd</p>
          <p>321 Pine Street, Miami, FL 33101 | EIN: 11-2233445</p>
          hero5
          services4
          how4
          pricing5
          cta3
        </div>
      )
    }
  